package com.example.allntrack;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;

public class SettingsActivity extends AppCompatActivity {

    private Switch darkModeSwitch;
    private Switch systemThemeSwitch;
    private Button logoutButton;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);

        sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        darkModeSwitch = findViewById(R.id.darkModeSwitch);
        systemThemeSwitch = findViewById(R.id.systemThemeSwitch);
        logoutButton = findViewById(R.id.logoutButton);
        ImageButton backButton = findViewById(R.id.backButton);

        // Set the initial state of the switches
        darkModeSwitch.setChecked(sharedPreferences.getBoolean("dark_mode", false));
        systemThemeSwitch.setChecked(sharedPreferences.getBoolean("system_theme", true));

        darkModeSwitch.setEnabled(!systemThemeSwitch.isChecked());

        darkModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }
            editor.putBoolean("dark_mode", isChecked);
            editor.apply();
        });

        systemThemeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            darkModeSwitch.setEnabled(!isChecked);
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
            }
            editor.putBoolean("system_theme", isChecked);
            editor.apply();
        });

        logoutButton.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Toast.makeText(SettingsActivity.this, "Logged out", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(SettingsActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });

        backButton.setOnClickListener(v -> {
            finish(); // Termina la actividad actual y vuelve a la anterior (HomeActivity)
        });
    }
}
