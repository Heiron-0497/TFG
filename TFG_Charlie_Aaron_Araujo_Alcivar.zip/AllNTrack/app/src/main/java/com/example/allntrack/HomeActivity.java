package com.example.allntrack;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

public class HomeActivity extends AppCompatActivity {

    private ViewPager2 imageSlider;
    private ImageSliderAdapter imageSliderAdapter;
    private ArrayList<Pedido> pedidosList;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String userEmail;
    private FloatingActionButton addButton;
    private FloatingActionButton settingsButton;
    private Timer sliderTimer;
    private androidx.cardview.widget.CardView imageSliderCard;
    private TabLayout sliderIndicator;

    private ImageButton amazonSettingsButton;
    private ImageButton zalandoSettingsButton;
    private ImageButton aliexpressSettingsButton;

    private boolean isAmazonLoggedIn;
    private boolean isZalandoLoggedIn;
    private boolean isAliexpressLoggedIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        imageSliderCard = findViewById(R.id.imageSliderCard);
        imageSlider = findViewById(R.id.imageSlider);
        sliderIndicator = findViewById(R.id.sliderIndicator);
        pedidosList = new ArrayList<>();
        imageSliderAdapter = new ImageSliderAdapter(this, pedidosList);
        imageSlider.setAdapter(imageSliderAdapter);

        mAuth = FirebaseAuth.getInstance();
        userEmail = getIntent().getStringExtra("userEmail");

        db = FirebaseFirestore.getInstance();

        // Habilitar la caché persistente
        FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .build();
        db.setFirestoreSettings(settings);

        loadImagesFromDatabase();

        // Inicializar los botones de la tienda
        Button amazonButton = findViewById(R.id.amazonButton);
        Button zalandoButton = findViewById(R.id.zalandoButton);
        Button aliexpressButton = findViewById(R.id.aliexpressButton);

        amazonSettingsButton = findViewById(R.id.amazonSettingsButton);
        zalandoSettingsButton = findViewById(R.id.zalandoSettingsButton);
        aliexpressSettingsButton = findViewById(R.id.aliexpressSettingsButton);

        checkLoginStatus();

        // Configurar el botón de añadir
        addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(v -> {
            Toast.makeText(HomeActivity.this, "This feature is still under development.", Toast.LENGTH_SHORT).show();
        });

        // Configurar el botón de configuración
        settingsButton = findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        // Configurar el temporizador para automatizar el deslizamiento
        setupAutoSlider();

        // Configurar el TabLayout como indicador
        new TabLayoutMediator(sliderIndicator, imageSlider, (tab, position) -> {}).attach();

        // Configurar el botón de Amazon
        amazonButton.setOnClickListener(v -> {
            if (isAmazonLoggedIn) {
                Intent intent = new Intent(HomeActivity.this, AmazonActivity.class);
                startActivity(intent);
            } else {
                Intent intent = new Intent(HomeActivity.this, AmazonLoginActivity.class);
                startActivity(intent);
            }
        });

        amazonSettingsButton.setOnClickListener(v -> showLogoutMenu(v, "amazon"));

        // Configurar el botón de Zalando
        zalandoButton.setOnClickListener(v -> {
            if (isZalandoLoggedIn) {
                Intent intent = new Intent(HomeActivity.this, ZalandoActivity.class);
                startActivity(intent);
            } else {
                Intent intent = new Intent(HomeActivity.this, ZalandoLoginActivity.class);
                startActivity(intent);
            }
        });

        zalandoSettingsButton.setOnClickListener(v -> showLogoutMenu(v, "zalando"));

        // Configurar el botón de AliExpress
        aliexpressButton.setOnClickListener(v -> {
            if (isAliexpressLoggedIn) {
                Intent intent = new Intent(HomeActivity.this, AliexpressActivity.class);
                startActivity(intent);
            } else {
                Intent intent = new Intent(HomeActivity.this, AliexpressLoginActivity.class);
                startActivity(intent);
            }
        });

        aliexpressSettingsButton.setOnClickListener(v -> showLogoutMenu(v, "aliexpress"));
    }

    private void checkLoginStatus() {
        isAmazonLoggedIn = getSharedPreferences("amazon_prefs", MODE_PRIVATE).getBoolean("is_logged_in", false);
        isZalandoLoggedIn = getSharedPreferences("zalando_prefs", MODE_PRIVATE).getBoolean("is_logged_in", false);
        isAliexpressLoggedIn = getSharedPreferences("aliexpress_prefs", MODE_PRIVATE).getBoolean("is_logged_in", false);

        amazonSettingsButton.setVisibility(isAmazonLoggedIn ? View.VISIBLE : View.GONE);
        zalandoSettingsButton.setVisibility(isZalandoLoggedIn ? View.VISIBLE : View.GONE);
        aliexpressSettingsButton.setVisibility(isAliexpressLoggedIn ? View.VISIBLE : View.GONE);
    }

    private void loadImagesFromDatabase() {
        db.collection("pedidos")
                .whereEqualTo("cliente", userEmail)
                .orderBy("fecha_pedido", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .limit(6)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        pedidosList.clear();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String cliente = document.getString("cliente");
                            String estadoPedido = document.getString("estado_pedido");
                            Timestamp fechaPedido = document.getTimestamp("fecha_pedido");
                            String imagen = document.getString("imagen");
                            String producto = document.getString("producto");
                            String tienda = document.getString("tienda");
                            if (imagen != null) {
                                pedidosList.add(new Pedido(cliente, estadoPedido, fechaPedido, imagen, producto, tienda));
                            }
                        }
                        imageSliderAdapter.notifyDataSetChanged();
                        // Mostrar u ocultar el CardView basado en la disponibilidad de pedidos
                        if (pedidosList.isEmpty()) {
                            imageSliderCard.setVisibility(View.GONE);
                        } else {
                            imageSliderCard.setVisibility(View.VISIBLE);
                        }
                    } else {
                        Toast.makeText(HomeActivity.this, "Failed to load images: " + Objects.requireNonNull(task.getException()).getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void setupAutoSlider() {
        sliderTimer = new Timer();
        sliderTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> {
                    int currentItem = imageSlider.getCurrentItem();
                    int totalItems = imageSliderAdapter.getItemCount();
                    if (currentItem < totalItems - 1) {
                        imageSlider.setCurrentItem(currentItem + 1);
                    } else {
                        imageSlider.setCurrentItem(0);
                    }
                });
            }
        }, 3000, 3000); // Cambia la página cada 3 segundos
    }

    private void showLogoutMenu(View view, String store) {
        PopupMenu popup = new PopupMenu(this, view);
        popup.getMenuInflater().inflate(R.menu.logout_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.logout) {
                logout(store);
                return true;
            }
            return false;
        });
        popup.show();
    }

    private void logout(String store) {
        String prefsName = store + "_prefs";
        getSharedPreferences(prefsName, MODE_PRIVATE).edit().putBoolean("is_logged_in", false).apply();
        checkLoginStatus();
        Toast.makeText(this, "Logged out from " + store, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sliderTimer != null) {
            sliderTimer.cancel();
        }
    }
}
