package com.example.allntrack;

import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ZalandoActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private PedidoAdapter pedidoAdapter;
    private List<Pedido> pedidoList;
    private List<Pedido> originalPedidoList;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zalando);

        TextView titleTextView = findViewById(R.id.titleTextView);
        titleTextView.setText("Zalando");

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        pedidoList = new ArrayList<>();
        originalPedidoList = new ArrayList<>();
        pedidoAdapter = new PedidoAdapter(this, pedidoList);
        recyclerView.setAdapter(pedidoAdapter);

        mAuth = FirebaseAuth.getInstance();
        userEmail = mAuth.getCurrentUser().getEmail();

        db = FirebaseFirestore.getInstance();
        loadZalandoPedidos();

        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        Button filterButton = findViewById(R.id.filterButton);
        filterButton.setOnClickListener(this::showFilterMenu);
    }

    private void loadZalandoPedidos() {
        db.collection("pedidos")
                .whereEqualTo("cliente", userEmail)
                .whereEqualTo("tienda", "Zalando")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        pedidoList.clear();
                        originalPedidoList.clear();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String cliente = document.getString("cliente");
                            String estadoPedido = document.getString("estado_pedido");
                            Timestamp fechaPedido = document.getTimestamp("fecha_pedido");
                            String imagen = document.getString("imagen");
                            String producto = document.getString("producto");
                            String tienda = document.getString("tienda");
                            if (imagen != null) {
                                Pedido pedido = new Pedido(cliente, estadoPedido, fechaPedido, imagen, producto, tienda);
                                pedidoList.add(pedido);
                                originalPedidoList.add(pedido);
                            }
                        }
                        pedidoAdapter.notifyDataSetChanged();
                    }
                });
    }

    private void showFilterMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.filter_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.filter_date) {
                showDateFilterMenu(view);
                return true;
            } else if (item.getItemId() == R.id.filter_status) {
                showStatusFilterMenu(view);
                return true;
            }
            return false;
        });
        popup.show();
    }

    private void showDateFilterMenu(View view) {
        PopupMenu datePopup = new PopupMenu(this, view);
        MenuInflater inflater = datePopup.getMenuInflater();
        inflater.inflate(R.menu.filter_date_menu, datePopup.getMenu());
        datePopup.setOnMenuItemClickListener(item -> {
            applyDateFilter(item.getItemId());
            return true;
        });
        datePopup.show();
    }

    private void showStatusFilterMenu(View view) {
        PopupMenu statusPopup = new PopupMenu(this, view);
        MenuInflater inflater = statusPopup.getMenuInflater();
        inflater.inflate(R.menu.filter_status_menu, statusPopup.getMenu());
        statusPopup.setOnMenuItemClickListener(item -> {
            applyStatusFilter(item.getItemId());
            return true;
        });
        statusPopup.show();
    }

    private void applyDateFilter(int itemId) {
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();
        Date startDate = null;
        Date endDate = currentDate;

        if (itemId == R.id.filter_last_month) {
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            startDate = calendar.getTime();
        } else if (itemId == R.id.filter_2024) {
            calendar.set(Calendar.YEAR, 2024);
            calendar.set(Calendar.DAY_OF_YEAR, 1);
            startDate = calendar.getTime();
            calendar.set(Calendar.YEAR, 2025);
            calendar.set(Calendar.DAY_OF_YEAR, 1);
            endDate = calendar.getTime();
        } else if (itemId == R.id.filter_2023) {
            calendar.set(Calendar.YEAR, 2023);
            calendar.set(Calendar.DAY_OF_YEAR, 1);
            startDate = calendar.getTime();
            calendar.set(Calendar.YEAR, 2024);
            calendar.set(Calendar.DAY_OF_YEAR, 1);
            endDate = calendar.getTime();
        } else if (itemId == R.id.filter_2022) {
            calendar.set(Calendar.YEAR, 2022);
            calendar.set(Calendar.DAY_OF_YEAR, 1);
            startDate = calendar.getTime();
            calendar.set(Calendar.YEAR, 2023);
            calendar.set(Calendar.DAY_OF_YEAR, 1);
            endDate = calendar.getTime();
        } else if (itemId == R.id.filter_2021) {
            calendar.set(Calendar.YEAR, 2021);
            calendar.set(Calendar.DAY_OF_YEAR, 1);
            startDate = calendar.getTime();
            calendar.set(Calendar.YEAR, 2022);
            calendar.set(Calendar.DAY_OF_YEAR, 1);
            endDate = calendar.getTime();
        }

        if (startDate != null) {
            List<Pedido> filteredList = new ArrayList<>();
            for (Pedido pedido : originalPedidoList) {
                Date pedidoDate = pedido.getFechaPedido().toDate();
                if (pedidoDate.after(startDate) && pedidoDate.before(endDate)) {
                    filteredList.add(pedido);
                }
            }

            pedidoList.clear();
            pedidoList.addAll(filteredList);
            pedidoAdapter.notifyDataSetChanged();
        }
    }

    private void applyStatusFilter(int itemId) {
        String status = null;
        if (itemId == R.id.filter_delivered) {
            status = "Entregado";
        } else if (itemId == R.id.filter_in_delivery) {
            status = "En reparto";
        } else if (itemId == R.id.filter_pending) {
            status = "Pendiente";
        }

        if (status != null) {
            List<Pedido> filteredList = new ArrayList<>();
            for (Pedido pedido : originalPedidoList) {
                if (pedido.getEstadoPedido().equalsIgnoreCase(status)) {
                    filteredList.add(pedido);
                }
            }

            pedidoList.clear();
            pedidoList.addAll(filteredList);
            pedidoAdapter.notifyDataSetChanged();
        }
    }
}
