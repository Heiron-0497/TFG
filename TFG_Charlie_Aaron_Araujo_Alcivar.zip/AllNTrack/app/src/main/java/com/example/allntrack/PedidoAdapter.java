package com.example.allntrack;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class PedidoAdapter extends RecyclerView.Adapter<PedidoAdapter.PedidoViewHolder> {

    private Context context;
    private List<Pedido> pedidoList;

    public PedidoAdapter(Context context, List<Pedido> pedidoList) {
        this.context = context;
        this.pedidoList = pedidoList;
    }

    @NonNull
    @Override
    public PedidoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_pedido, parent, false);
        return new PedidoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PedidoViewHolder holder, int position) {
        Pedido pedido = pedidoList.get(position);
        holder.productoTextView.setText(pedido.getProducto());
        holder.fechaPedidoTextView.setText(pedido.getFormattedFechaPedido());
        holder.estadoPedidoTextView.setText(pedido.getEstadoPedido());
        holder.tiendaTextView.setText(pedido.getTienda());
        Glide.with(context).load(pedido.getImagen()).fitCenter().into(holder.imagenImageView);

        // Set card height to 1/4 of screen height
        ViewGroup.LayoutParams layoutParams = holder.itemView.getLayoutParams();
        layoutParams.height = (int) (context.getResources().getDisplayMetrics().heightPixels * 0.25);
        holder.itemView.setLayoutParams(layoutParams);
    }

    @Override
    public int getItemCount() {
        return pedidoList.size();
    }

    public static class PedidoViewHolder extends RecyclerView.ViewHolder {

        TextView productoTextView;
        TextView fechaPedidoTextView;
        TextView estadoPedidoTextView;
        TextView tiendaTextView;
        ImageView imagenImageView;

        public PedidoViewHolder(@NonNull View itemView) {
            super(itemView);
            productoTextView = itemView.findViewById(R.id.productoTextView);
            fechaPedidoTextView = itemView.findViewById(R.id.fechaPedidoTextView);
            estadoPedidoTextView = itemView.findViewById(R.id.estadoPedidoTextView);
            tiendaTextView = itemView.findViewById(R.id.tiendaTextView);
            imagenImageView = itemView.findViewById(R.id.imagenImageView);
        }
    }
}
