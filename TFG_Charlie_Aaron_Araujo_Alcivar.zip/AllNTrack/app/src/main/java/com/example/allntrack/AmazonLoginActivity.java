package com.example.allntrack;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AmazonLoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amazon_login);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);

        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(AmazonLoginActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            } else {
                // Simulate login process
                if (username.equals("testuser") && password.equals("password")) {
                    // Save login status in SharedPreferences
                    getSharedPreferences("amazon_prefs", MODE_PRIVATE).edit().putBoolean("is_logged_in", true).apply();
                    // Proceed to AmazonActivity
                    Intent intent = new Intent(AmazonLoginActivity.this, AmazonActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(AmazonLoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
