package com.example.allntrack;

import com.google.firebase.Timestamp;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class Pedido {
    private String cliente;
    private String estadoPedido;
    private Timestamp fechaPedido;
    private String imagen;
    private String producto;
    private String tienda;

    // Constructor, getters y setters

    public Pedido(String cliente, String estadoPedido, Timestamp fechaPedido, String imagen, String producto, String tienda) {
        this.cliente = cliente;
        this.estadoPedido = estadoPedido;
        this.fechaPedido = fechaPedido;
        this.imagen = imagen;
        this.producto = producto;
        this.tienda = tienda;
    }

    public String getCliente() {
        return cliente;
    }

    public String getEstadoPedido() {
        return estadoPedido;
    }

    public Timestamp getFechaPedido() {
        return fechaPedido;
    }

    public String getImagen() {
        return imagen;
    }

    public String getProducto() {
        return producto;
    }

    public String getTienda() {
        return tienda;
    }

    public String getFormattedFechaPedido() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy", Locale.getDefault());
        return sdf.format(fechaPedido.toDate());
    }
}
